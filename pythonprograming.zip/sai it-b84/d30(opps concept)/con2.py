class book:
    def __init__(self, title,author="unknown",year=2000):
        self.title = title
        self.author = author
        self.year = year
b1=book("python")
b2=book("java","sai",2020)
print(b1.title,b1.author,b1.year)
print(b2.title,b2.author,b2.year)

