#class with direct----
class student:
    def __init__(self,name):
        self.name = name
        self.grades={}
    def add_grades(self,subject,grades):
        self.grades[subject] =grades
s=student("sai")
s.add_grades("python",50)
s.add_grades("c",45)
print(s.name,s.grades)