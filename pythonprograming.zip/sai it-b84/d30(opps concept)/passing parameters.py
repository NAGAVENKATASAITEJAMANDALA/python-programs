class person:
    def name(self,names):
        self.names=names
    def getname(self):
        return self.names
p=person()
p.name("sai")
print(p.getname())