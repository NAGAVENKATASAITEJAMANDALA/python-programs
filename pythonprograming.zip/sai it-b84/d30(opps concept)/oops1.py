#class creation,access class through obj
class dog:
    def features(self):
        print("geraman shepard")
        print("austria")
animal=dog()
animal.features()