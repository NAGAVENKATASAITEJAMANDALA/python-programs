pi=3.14
class circle:
    def val(self,r,pi):
        self.pi =  pi
        self.r=r
        #pi=3.14
    def area(self):
        return self.pi*self.r*self.r
    def cir(self):
        return 2*self.pi*self.r
c=circle()
r = int(input())
c.val(r,pi)
print(c.area())
print(c.cir())