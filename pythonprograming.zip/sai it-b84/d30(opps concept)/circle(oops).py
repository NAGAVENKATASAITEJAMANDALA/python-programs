pi=3.14
class circle:
    def val(self,r):
        self.r=r
    def area(self):
        return pi*self.r*self.r
    def cir(self):
        return 2*pi*self.r
c=circle()
c.val(int(input()))
print(c.area())
print(c.cir())