class Mops:
    def op(self, a, b):
        result = []
        for i in range(len(a)):
            r = []
            for j in range(len(a[0])):
                r.append(a[i][j] + b[i][j])  # Adding elements of the matrices
            result.append(r)
        return result
class Sub(Mops):
    def op(self, a, b):
        result = []
        for i in range(len(a)):
            r = []
            for j in range(len(a[0])):
                r.append(a[i][j] - b[i][j])  
            result.append(r)
        return result
class Mul(Mops):
    def op(self, a, b):
        result = []
        for i in range(len(a)):
            r = []
            for j in range(len(b[0])):  
                val = 0
                for k in range(len(a[0])):  
                    val += a[i][k] * b[k][j]  
                r.append(val)
            result.append(r)
        return result
def matrix_name(name):
    r = int(input(f"Enter number of rows for {name}: "))
    c = int(input(f"Enter number of columns for {name}: "))
    matrix = []
    print(f"Enter elements of {name}:")
    for i in range(r):
        row = list(map(int, input(f"Row {i+1}: ").split()))  
        matrix.append(row)
    return matrix
a = matrix_name('A')
b = matrix_name('B')
print("Choose operation:\n1. Add\n2. Subtract\n3. Multiply")
choice = int(input("Enter choice (1/2/3): "))  
if choice == 1:
    op = Mops()
elif choice == 2:
    op = Sub()
elif choice == 3:
    op = Mul()
else:
    print("Invalid choice")
    exit()
result=op.op(a,b)
for r in result:
    print(r)
