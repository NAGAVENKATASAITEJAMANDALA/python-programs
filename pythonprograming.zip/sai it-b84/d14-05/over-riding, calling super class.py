'''over-riding, calling super clas attribute
     progam to cal areaof ircle y method overridng
            by callig super class'''
class shape:
    def area(self):
        print("deploy area of circle")
class circle(shape):
    def area(self):
        print("cal area")
        return super().area()
c=circle()
c.area()