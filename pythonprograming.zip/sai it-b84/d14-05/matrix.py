''' progrm to create matrix operation class to wor with derent operations'''
class mops:
    def op(self,a,b):
        result=[]
        for i in range(len(a)):
            r=[]
            for j in range (len(a[0])):
                r.append(a[i][j]+b[i][j])
                result.append(r)
            return result
class sub(mops):
    def op(self,a,b):
        result=[]
        for i in range(len(a)):
            r=[]
            for j in range (len(a[0])):
                r.append(a[i][j]-b[i][j])
                result.append(r)
            return result
class mul(mops):
    def op(self,a,b):
        result=[]
        for i in range(len(a)):
            r=[]
            for j in range (len(b[0])):
                val=0
                for k in range(len(b)):
                    val+=a[i][k]*b[k][j]
                    r.append(val)
                result.append(r)
            return result
def matrix_name(name):
    r=int(input(f"enter number of row for {name}"))
    c=int(input(f"enter number of col for {name}"))
    matrix=[]
    print(f"enter elemenetsof {name}")
    for i in range(r):
        r=list(map(int,input(f"row{i+1}").split()))
        matrix.append(r)
    return matrix
a=matrix_name('a')
b=matrix_name("b")
print("1.add,2.sub,3.mul")
choice = input("Enter choice (1/2/3): ")

if choice == "1":
    op = mops()
elif choice == "2":
    op = sub()
elif choice == "3":
    op = mul()
else:
    print("Invalid choice")
    exit()

result=op.operator(a,b)
for r in reult:
    print(r)