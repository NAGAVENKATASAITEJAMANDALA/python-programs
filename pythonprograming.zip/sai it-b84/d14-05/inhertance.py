#over-riding method in a su class
class vechicle:
    def start(self):
        print("vechical is starting")
class car(vechicle):
    def start(self):
        print("caris starting wth key")
class bike(vechicle):
    def start(self):
        print("bike is starting with kick")
v=vechicle()
c=car()
b=bike()
v.start()
c.start()
b.start()