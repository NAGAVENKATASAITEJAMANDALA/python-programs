class person:
    def hi(self):
        return "hello, how are you"
class friend:
    def hi(self):
        return" hi"
class stanger:
    def hi(self):
        return "who are you"
p=person()
f=friend()
s=stanger()
print(p.hi())
print(f.hi())
print(s.hi())