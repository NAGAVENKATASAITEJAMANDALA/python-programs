n=int(input("enter number of star"))
for i in range(n):
    print("*",end=" ")