n=int(input("enter number of rows"))
for i in range(n):
    print("* "*n)
