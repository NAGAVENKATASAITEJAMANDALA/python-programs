row=int(input())
for i in range(1,row+1):
    for space in range(row-1):
        print(" ",end="")
    for j in range(1,i+1):
        print(j,end=" ")
    print()