try:
    n1=int(input("enter a number"))
    print(n1**3)
except(KeyboardInterrupt,ValueError,TimeoutError,TypeError):
    print("check error before executing")
print("program Terminating")