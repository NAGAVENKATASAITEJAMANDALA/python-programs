import math
try:
    n1=int(input("enter a number"))
    if n1<0:
        raise ValueError
except ValueError:
    print("enter postive number")
else:
    print("squareRoot",round(math.sqrt(n1),4))