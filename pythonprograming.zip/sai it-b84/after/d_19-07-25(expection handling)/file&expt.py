import datetime
try:
    n1 = int(input("Enter a number: "))
    print(n1 ** 3)
except (KeyboardInterrupt, ValueError, TimeoutError, TypeError) as e:
    with open("error_log.txt", "a") as file:
        file.write(f"Error occurred: {type(e).__name__}\n")
    print("Check error before executing")
print("Program terminating")
