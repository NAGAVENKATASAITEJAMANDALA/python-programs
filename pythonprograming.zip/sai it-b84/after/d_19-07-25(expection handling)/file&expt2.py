import datetime
try:
    n1 = int(input("Enter a number: "))
    print(n1 ** 3)
except (KeyboardInterrupt, ValueError, TimeoutError, TypeError) as e:
    currenttime = datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    with open("error_log.txt", "a") as file:
        file.write(f"{currenttime} - Error occurred: {type(e).__name__}\n")
    print("Check error before executing")
print("Program terminating")