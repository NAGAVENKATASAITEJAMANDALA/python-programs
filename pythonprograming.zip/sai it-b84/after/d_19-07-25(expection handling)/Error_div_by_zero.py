try:
    n1=int(input("Enter first number: "))
    n2=int(input("Enter second number: "))
    result = n1 / n2
    print(f"The result of {n1} / {n2} is {result}.")
except ZeroDivisionError:
    print("Error: Division by zero is not allowed.")