class Transaction:
    def __init__(self,tranmsaction_type,amount):
        self.type=tranmsaction_type
        self.amount=amount
        self.next=None
class TransactionHistory:
        def __init__(self):
            self.head=None
        def add_transaction(self,transaction_type,amount):
            nn=Transaction(transaction_type,amount)
            if not self.head:
                self.head=nn
            else:
                current=self.head
                while current.next:
                    current=current.next
                current.next=nn
            print("f{transaction_type} of Rs.{amount} recorded....")
        def show_history(self):
            if not self.head:
                print("No Transaction Found.....")
                return
            print("\n Transaction History")
            current=self.head
            count=1
            while current :
                print(f"{count},{current.type}-Rs{current.amount}")
                current=current.next
                count+=1
history=TransactionHistory()

while True:
    print("\n-----------ATM Transaction Menu------------")
    print("1.Deposit")
    print("2.Withdraw")
    print("3.Historty")
    print("4.Exit")
    choice=input("Enter your choice:")
    if choice=='1':
        amount=float(input("Enter amount to deposit:"))
        history.add_transaction("Deposit:",amount)
    elif choice=='2':
        amount=float(input("Enter Amount to Withdraw:"))
        history.add_transaction("WithDraw",amount)
    elif choice=='3':
        history.show_history()
    elif choice=='4':
        print("End of Transaction.....EXit!!!")
        break
    else:
        print("Choose 1/2/3/4 only.....")
        

           

