""" 
binary search
1.array must be sorted
2.array is div to 2 half seperactly(div & conq)
3.set low & figh 0->n-1
condition low<=high
mid=low + high//2
arr[mid]==key return mid
arr[mid<key]low + mid+1
arr[mid>key] high mid-1
not found return -1"""
def binarysearch(arr, key):
    low = 0
    high = len(arr) - 1
    while low <= high:
        mid = (low + high) // 2
        if arr[mid] == key:
            return mid
        elif arr[mid] < key:
            low = mid + 1
        else:
            high = mid - 1
    return -1  # key not found

# Input
size = int(input("Enter number of elements: "))
arr = []
for i in range(size):
    num = int(input(f"Element {i+1}: "))
    arr.append(num)

# Sort the array before binary search
arr.sort()
print(f"Sorted array: {arr}")

# Search
key = int(input("Enter the element to search: "))
result = binarysearch(arr, key)

# Output
if result != -1:
    print(f"\nElement {key} found at index {result}")
else:
    print(f"\nElement {key} not found in array")
