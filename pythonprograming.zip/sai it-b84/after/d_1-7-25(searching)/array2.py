#ARRAY OPARATION
#PROGRAM TO CONSIDER A LIST ARR=[10,20,30,40]AND PERFORM THE INSERT OPERATION
#AND DELETION OPERATION WITH 50 AND 25 AT POSITION 2,DELETE 30 AND TRANSWER THE ARRAY TO FETCH A NUMBER 25
arr=list (map(int,input().split()))
arr.append(50)
arr.insert(2,25)
print(arr)
arr.pop()
print(arr)
if 25 in arr:
    print("yes")
else:
    print("no")
