def bina(nums,key):
    low=0
    high=len(nums)-1
    while low<=high:
        mid=(low+high)//2
        if nums[mid]==key:
            return mid
        elif nums[mid]<key:
            low=mid+1
        else:
            high=mid-1
    return -1
size = int(input("Enter number of elements: "))
nums = list(map(int, input().split()))
if len(nums)!=size:
    print(f"enter only{size} numbers")
else:
    nums.sort()
    print(nums)
    key=int(input("enter key to search"))
    result=bina(nums,key)
    if result!=-1:
        print(f"the  {key} element found at{result}")
    else:
        print(f"element{key}is not found")