class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoubleLinkedList:
    def __init__(self):
        self.head = None

    def iab(self, data):  
        newnode = Node(data)
        newnode.next = self.head
        if self.head:
            self.head.prev = newnode
        self.head = newnode

    def iae(self, data):  
        newnode = Node(data)
        if not self.head:
            self.head = newnode
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = newnode
        newnode.prev = temp

    # Delete node by value
    def delete_by_value(self, value):
        if not self.head:
            print("Can't perform delete on an empty list...")
            return

        temp = self.head
        # If head node itself holds the value
        if temp.data == value:
            print(f"Deleted node with value: {value}")
            self.head = temp.next
            if self.head:
                self.head.prev = None
            return

        # Search for the node to delete
        while temp and temp.data != value:
            temp = temp.next

        # Value not found
        if not temp:
            print(f"Value {value} not found in the list.")
            return

        # If node to be deleted is in the middle or end
        print(f"Deleted node with value: {value}")
        if temp.next:
            temp.next.prev = temp.prev
        if temp.prev:
            temp.prev.next = temp.next

    def display(self):  
        temp = self.head
        print("Double Linked List forward:")
        while temp:
            print(temp.data, end=" <-> " if temp.next else "")
            temp = temp.next
        print(" None")

    def backtraverse(self): 
        print("Double Linked List (reverse):")
        if not self.head:
            print("Empty list")
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        while temp:
            print(temp.data, end=" <-> " if temp.prev else "")
            temp = temp.prev
        print(" None")

    def print_element_at(self, position):
        if position <= 0:
            print("Position should be >= 1")
            return
        temp = self.head
        count = 1
        while temp and count < position:
            temp = temp.next
            count += 1
        if not temp:
            print(f"Position {position} is out of range.")
        else:
            print(f"Element at position {position} is: {temp.data}")

# Example usage:
dll = DoubleLinkedList()
n = int(input("Enter number of elements to insert at end: "))
for i in range(n):
    val = int(input(f"Enter element {i+1}: "))
    dll.iae(val)
dll.display()

# Delete nodes by value
d = int(input("\nHow many nodes do you want to delete by value? "))
for _ in range(d):
    v = int(input("Enter value to delete: "))
    dll.delete_by_value(v)
    dll.display()

pos = int(input("\nEnter position to print element: "))
dll.print_element_at(pos)
print("\nBackward traversal:")
dll.backtraverse()
