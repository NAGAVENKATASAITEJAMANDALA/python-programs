class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoubleLinkedList:
    def __init__(self):
        self.head = None
    def iab(self, data):  
        newnode = Node(data)
        newnode.next = self.head
        if self.head:
            self.head.prev = newnode
        self.head = newnode
    def iae(self, data):  
        newnode = Node(data)
        if not self.head:
            self.head = newnode
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = newnode
        newnode.prev = temp

    def dab(self): 
        if not self.head:
            print("Can't perform delete on an empty list...")
            return
        print(f"Deleted from beginning: {self.head.data}")
        self.head = self.head.next
        if self.head:
            self.head.prev = None

    def dae(self):  
        if not self.head:
            print("Can't perform delete on an empty list...")
            return
        temp = self.head
        if not temp.next:
            print(f"Deleted from end: {temp.data}")
            self.head = None
            return
        while temp.next:
            temp = temp.next
        print(f"Deleted from end: {temp.data}")
        temp.prev.next = None

    def display(self):  
        temp = self.head
        print("Double Linked List forward:")
        while temp:
            print(temp.data, end=" <-> " if temp.next else "")
            temp = temp.next
        print(" None")

    def backtraverse(self): 
        print("Double Linked List (reverse):")
        if not self.head:
            print("Empty list")
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        while temp:
            print(temp.data, end=" <-> " if temp.prev else "")
            temp = temp.prev
        print(" None")

    def print_element_at(self, position):
        if position <= 0:
            print("Position should be >= 1")
            return
        temp = self.head
        count = 1
        while temp and count < position:
            temp = temp.next
            count += 1
        if not temp:
            print(f"Position {position} is out of range.")
        else:
            print(f"Element at position {position} is: {temp.data}")

dll = DoubleLinkedList()
n = int(input("Enter number of elements to insert at end: "))
for i in range(n):
    val = int(input(f"Enter element {i+1}: "))
    dll.iae(val) 
dll.display()
d = int(input("\nHow many times do you want to delete from beginning? "))
for _ in range(d):
    dll.dab()
dll.display()
e = int(input("\nHow many times do you want to delete from end? "))

for _ in range(e):
    dll.dae()
dll.display()
pos = int(input("\nEnter position to print element: "))
dll.print_element_at(pos)
print("\nBackward traversal:")
dll.backtraverse()