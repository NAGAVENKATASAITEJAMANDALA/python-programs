class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoubleLinkedList:
    def __init__(self):
        self.head = None

    def iae(self, data): 
        newnode = Node(data)
        if self.head is None:
            self.head = newnode
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = newnode
        newnode.prev = temp

    def display_forward(self):  
        temp = self.head
        print("Forward traversal:")
        while temp:
            print(temp.data, end=" <-> ")
            temp = temp.next
        print("None")

    def display_backward(self):
        if not self.head:
            print("List is empty")
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        print("Backward traversal:")
        while temp:
            print(temp.data, end=" <-> ")
            temp = temp.prev
        print("None")
dll = DoubleLinkedList()
n = int(input("Enter the number of elements to insert at end: "))
for i in range(n):
    val = int(input(f"Enter element {i+1}: "))
    dll.iae(val)

dll.display_forward()
dll.display_backward()