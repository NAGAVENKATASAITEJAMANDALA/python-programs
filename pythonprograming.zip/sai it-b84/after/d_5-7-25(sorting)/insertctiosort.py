def inserctiionsort(arr):
    for i in range(1,len(arr)):
        key=arr[i]
        j=i-1
        while j>=0 and key<arr[j]:
            arr[j+1]=arr[j]
            j=j-1
        arr[j+1]=key
    return arr
size=int(input('enter numer of elements'))
arr=[]
print('enter',size,'elements')
for i in range(size):
    num=int(input())
    arr.append(num)
print(arr)
result=inserctiionsort(arr)
print('sorted array',result)