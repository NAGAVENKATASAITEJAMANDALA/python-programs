class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
class LinkedList:
    def __init__(self):
        self.head = None

    def insertatbeg(self, data):
        newnode = Node(data)
        newnode.next = self.head
        self.head = newnode
    def insertatend(self, data):
        newnode = Node(data)
        if self.head is None:
            self.head = newnode
            print(f"{data} isert at end")
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = newnode
        print(f"{data} inserted last")
    def ipa(self, data, pos):  # Insert at Position
        newnode = Node(data)
        if pos == 1:
            newnode.next = self.head
            self.head = newnode
            print(f"{data} insert at pos-1")
            return
        current = self.head
        count = 1
        while current and count < pos - 1:
            current = current.next
            count += 1
        if not current:
            print("Position out of bounds")
            return
        newnode.next = current.next
        current.next = newnode
        print(f"{data} inserted at position {pos}")
    def display(self):
        current = self.head
        if not current:
            print("Linked list is empty")
            return
        while current:
            print(current.data, end="-->")
            current = current.next
        print("None")
l1 = LinkedList()
while True:
    print("\nLinked List - Insert at Beginning")
    print("1. Insert at beging \n2. insert at end \n3. insert at pos \n4. display \n5.exit")
    choice = int(input("Enter your choice: "))
    if choice == 1:
        data = int(input("Enter value to insert: "))
        l1.insertatbeg(data)
    elif choice == 2:
        data = int(input("Enter value to insert:a "))
        l1.insertatend(data)
    elif choice == 3:
        data = int(input("Enter value to insert: "))
        pos = int(input("Enter position to insert at: "))
        l1.ipa(data, pos)
    elif choice == 4:
        l1.display()
    elif choice == 5:
        print("Exit")
        break
    else:
        print("Invalid choice")