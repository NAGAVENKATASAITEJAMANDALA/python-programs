import math
def jumpsearch(arr, target):
    if not arr:
        return -1
    n = len(arr)
    step = int(math.sqrt(n))
    prev = 0
    # Finding the block where element may be present
    while prev < n and arr[min(prev + step, n) - 1] < target:
        prev += step
    # Linear search in the identified block
    for i in range(max(0, prev - step), min(n, prev + 1)):
        if arr[i] == target:
            return i
    return -1
size = int(input("Enter number of elements: "))
arr = list(map(int, input(f"Enter {size} sorted elements separated by space: ").split()))
if len(arr) != size:
    print(f" Error: Expected {size} elements, got {len(arr)}.")
else:
    arr.sort()
    target = int(input("Enter element to search: "))
    result = jumpsearch(arr, target)
    if result != -1:
        print(f" Element {target} found at index {result}.")
    else:
        print(f"Element {target} not found.")