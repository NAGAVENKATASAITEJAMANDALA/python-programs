import pygame
import sys
import random

# --- Constants (assuming these are defined elsewhere in your full code) ---
# Example values, adjust as per your game's requirements
width = 600
height = 600
block_size = 25
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0) # For snake
BLUE = (0, 0, 255)  # For food

pygame.init()
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption('Snake Game')
font = pygame.font.Font(None, 40)
clock = pygame.time.Clock()

# --- Helper Functions (assuming these are defined elsewhere) ---
def spawn_food(snake):
    while True:
        food_x = random.randrange(0, width // block_size) * block_size
        food_y = random.randrange(0, height // block_size) * block_size
        food = (food_x, food_y)
        if food not in snake:
            return food

def draw_snake(snake):
    for segment in snake:
        pygame.draw.rect(screen, GREEN, pygame.Rect(segment[0], segment[1], block_size, block_size))

def draw_food(food):
    pygame.draw.rect(screen, BLUE, pygame.Rect(food[0], food[1], block_size, block_size))

# --- Corrected game_loop function ---
def game_loop():
    def init_game():
        snake = [(width // 2, height // 2)]  # Start in the middle
        direction = 'RIGHT'
        change = direction  # 'change' tracks the pending direction change
        food = spawn_food(snake)
        score = 0
        return snake, direction, change, food, score

    snake, direction, change, food, score = init_game()

    while True:
        # Event handling for game play
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP and direction != 'DOWN':
                    change = 'UP'
                elif event.key == pygame.K_DOWN and direction != 'UP':
                    change = 'DOWN'
                elif event.key == pygame.K_LEFT and direction != 'RIGHT':
                    change = 'LEFT'
                elif event.key == pygame.K_RIGHT and direction != 'LEFT':
                    change = 'RIGHT'

        # Update direction based on player input
        direction = change

        # Calculate new head position
        x, y = snake[0]
        if direction == 'UP':
            y -= block_size
        elif direction == 'DOWN':
            y += block_size
        elif direction == 'LEFT':
            x -= block_size
        elif direction == 'RIGHT':
            x += block_size

        head = (x, y)

        # Check for game over conditions
        if x < 0 or x >= width or y < 0 or y >= height or head in snake[1:]: # head in snake[1:] to avoid collision with itself initially
            # Game over screen
            screen.fill(BLACK)
            msg = font.render(f'Game Over! Score: {score}', True, RED)
            msg_rect = msg.get_rect(center=(width // 2, height // 3))
            screen.blit(msg, msg_rect)

            restart_msg = font.render('Press SPACE to Restart or ESC to Quit', True, WHITE)
            restart_msg_rect = restart_msg.get_rect(center=(width // 2, height // 2))
            screen.blit(restart_msg, restart_msg_rect)
            pygame.display.update()

            waiting = True
            while waiting:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    elif event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE:
                            snake, direction, change, food, score = init_game()
                            waiting = False
                        elif event.key == pygame.K_ESCAPE:
                            pygame.quit()
                            sys.exit()
            # After restarting, the outer loop will continue, so no 'continue' needed here.
            # The 'continue' statement was problematic as it would skip the rest of the game loop logic
            # for the current iteration after a restart, leading to potential display issues.

        else: # Only proceed with game logic if not game over
            snake.insert(0, head)

            if head == food:
                score += 1
                food = spawn_food(snake)
            else:
                snake.pop()

            # Drawing
            screen.fill(BLACK)
            draw_snake(snake)
            draw_food(food)

            score_text = font.render(f'Score: {score}', True, WHITE)
            screen.blit(score_text, (10, 10))

            pygame.display.update()
            clock.tick(7) # Control game speed

# To run the game:
if __name__ == '__main__':
    game_loop()