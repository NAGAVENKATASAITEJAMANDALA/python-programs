age=int(input())
age=int(input("enter age"))
