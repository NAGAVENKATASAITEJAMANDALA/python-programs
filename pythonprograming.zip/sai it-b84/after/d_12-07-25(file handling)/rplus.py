with open("teaa.txt",'w') as f:
    f.write("sai teja")
with open("teaa.txt",'r+') as f:
    data=f.read()
    print("previous:",data)
    new_data=data.replace("teja","vinay")
    f.seek(0)
    f.write(new_data)
    f.truncate(9) #remove the remainng char
with open("teaa.txt","r") as f:
    print("latest data",f.read())