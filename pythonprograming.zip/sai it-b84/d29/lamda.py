sq=lambda x:x*x
add=lambda a,b:a+b
div=lambda a,b:a/b
print(sq(4),add(10,5),div(5,10))