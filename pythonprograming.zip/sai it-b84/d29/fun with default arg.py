def result(a,b=1):
    return a*b
print(result(5))
print(result(5,10))