def total(a,b):
    c=a+b
    return c
result=total(10,11)
print("sum is",result)
