def tot(*args):
    return sum(args)
print(tot(1,2,3,4,5))
print(tot(11,22,45,42,21,45,21,20))
