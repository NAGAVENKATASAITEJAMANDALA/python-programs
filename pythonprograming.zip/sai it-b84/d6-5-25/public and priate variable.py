class abc():
    def __init__(self,v1,v2):
        self.v1=v1#public
        self.__v2=v2#private
    def display(self):
        print("from class method var 1",self.v1)
        print("fromclass mathod var2",self.__v2)
obj=abc(11,22)
obj.display()
print("from obj1,var1=",obj.v1)
print("from obj,var2=",obj.__v2)
