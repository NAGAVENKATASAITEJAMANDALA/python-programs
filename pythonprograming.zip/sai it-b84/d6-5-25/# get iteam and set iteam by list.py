# get iteam and set iteam by list
class nums:
    def __init__(self,list):
        self.list = list
    def __getitem__(self,index):
        return self.list[index]
    def __setitem__(self,index,value):
        self.list[index] = value
nl=nums([1,2,3,4,5,6,4])
print(nl[5])
nl[3] = 100
print(nl.list)