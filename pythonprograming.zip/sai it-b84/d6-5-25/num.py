class num:
    def __init__(self, a,b):  
        self.a = a
        self.b = b
        print(f"intialisation with a={a},b={b}")
    def add (self):
        return self.a+self.b
    def sub (self):
        return self.a-self.b
    def mul (self):
        return self.a*self.b
    def div (self,):
        if self.b!=0:
            return self.a/self.b
        else:
            return  "no"
    def __del__(self):
        print(f"del obj with a={self.a},{self.b}")
n1=int(input())
n2=int(input())
op=num(n1,n2)
print("add",op.add())
print("add",op.sub())
print("add",op.mul())
print("add",op.div())