# code for del __del__()
class abc():
    classvar=0
    def __init__(self,var):
        abc.classvar+=1
        self.var=var
        print("the objective value is",var)
        print("the value of class variable is:",abc.classvar)   
obj1=abc(10)
obj2=abc(20)
obj3=abc(30)    
