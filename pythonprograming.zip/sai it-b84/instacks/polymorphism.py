class python:
    def flexible(self):
        print("python is flexible")
    def oops(self):
        print("python support oops")
class java:
    def flexible(self):
        print("python is flexible")
    def oops(self):
        print("python support oops")
py=python()
ja=java()
py.flexible()
py.oops()
ja.flexible()
ja.oops()