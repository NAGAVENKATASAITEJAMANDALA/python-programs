def write():
    roll = input("Enter roll number: ")
    name = input("Enter name: ")
    mobile = input("Enter mobile number: ")

    with open('student.txt', 'a') as f:
        f.write(roll + '\t' + name + '\t' + mobile + '\n')

    print("Data registered successfully.")
