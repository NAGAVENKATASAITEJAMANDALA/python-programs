class number:
    def __init__(self):
        self.a=int(input("enter a number "))
    def show(self):
        print("inside the base class ")
        print("the value of a is",self.a)
class string(number):
    def __init__(self):
        self.s=input("enter string")
        number.__init__(self)
    def show1(self):
        print("insied the drived class")
        print("the value of drived class is",self.s)
obj=string()
obj.show()
obj.show1()