import sys
a=int(input())
b=int(input())
try:
    c=a/b
    print(c)
except:
    print("not possible")