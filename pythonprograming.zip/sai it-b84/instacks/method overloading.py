def msg():
    print('Msg () exicuted with out arg')
def msg(a):
    print('Msg () exicuted with 1 arg')
def msg(a,b):
    print('Msg () exicuted with 2 arg')
msg(10,30)
''' method overloding is used to decelare only the latest
    method'''