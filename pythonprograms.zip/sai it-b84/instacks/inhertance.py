class number:
    def input(self):
        self.a=int(input("enter a"))
    def show(self):
        print("inside the base class")
        print("the value of a is",self.a)
class string(number):
    def input1(self):
        self.s=input("enter")
    def show1(self):
        print("drived class",self.s)
obj=string()
obj.input()
obj.input1()
obj.show()
obj.show1()