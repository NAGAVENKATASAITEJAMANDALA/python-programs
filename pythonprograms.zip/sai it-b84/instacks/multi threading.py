from threading import Thread
class Demo(Thread): #thread 1
    def run(self):
        for i in range(0,5):
            print('Thread 1')
class software(Thread): # thread 2
    def run(self):
        for i in range(0,5):
            print('Thread 2')
t1=Demo()
t2=software()
t1.start()
t2.start()