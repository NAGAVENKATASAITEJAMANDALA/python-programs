class number:
    def input(self,a):
        self.a=a
    def show(self):
        print("inside the base class")
        print("the value is ",self.a)
class string(number):
    def input(self,s):
        self.s=s
    def show1(self):
        print("inside the drived class")
        print("the value Of string is " ,self.s)

obj=string()
obj.a=int(input("enter a number "))
obj.s=input("enter the value ")
obj.show()
obj.show1()