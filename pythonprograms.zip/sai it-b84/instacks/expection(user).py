class Error(Exception):
    pass
class ValueTooSmallError(Exception):
    pass
class ValueTooLargeError(Exception):
    pass
n=int(input("enter a number"))
while(True):
    try:
        temp=int(input("entter number to compair"))
        if(temp<n):
            raise ValueTooSmallError
        elif(temp>n):
            raise ValueTooLargeError
        else:
            print("equal")
        break
    except ValueTooSmallError:
        print("number is small")
        print()
    except ValueTooLargeError:
        print("value is big")
        print()