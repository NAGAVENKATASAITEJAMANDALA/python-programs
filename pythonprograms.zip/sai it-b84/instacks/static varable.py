class Student:
    branch='It'#class varable/static varable
    def __init__(self,a,b):
        self.a=a  # instance varable
        self.b=b #instance varable
    # name and roll nuber can be different but the branch is same
    def __str__(self):
        return(f" name is {self.a} \n rollno {self.b} \n Branch {Student.branch}")
a=input("enter name ")
b=int(input("roll number "))
obj1=Student(a,b)
print(obj1)
a=input("enter name ")
b=int(input("roll number "))
obj2=Student(a,b)
print(obj2)