class demo:
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def __add__(self,other):
        return( self.a+other.a,self.b+other.b)
    def display(self):
        print(self.a+self.b)
a = new_func()
b=int(input("enter a number"))
obj1=demo(a,b)
obj1.display()
a=input("enter a string")
b=input("enter a string")
obj2=demo(a,b)
obj2.display()