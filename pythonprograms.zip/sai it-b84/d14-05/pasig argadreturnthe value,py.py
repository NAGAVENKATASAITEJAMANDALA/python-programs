'''pasig argadreturnthe value
           proram to pass args of sal of dierent emp from a super class to sub class
           tkae asuper class as ep and drived class as manager and pass amount with 10(manager) and 20(developper) %
                       as increment'''
class employee:
    def salary(self,cash):
        print(f"employee sal is {cash}")
class manaer(employee):
    def salary(self, cash):
        print(f"manager sal is ", round (cash*1.1 ))
class developer(employee):
    def salary(self, cash):
        print(f"deeloper salis:", round (cash*1.2 ))
e=employee()
m=manaer()
d=developer()
e.salary(50000)
m.salary(50000)
d.salary(50000)
