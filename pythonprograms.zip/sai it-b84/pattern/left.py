n = int(input("Enter number of rows: "))
for row in range(1, n + 1):
    for space in range(n - row+1):
        print("  ", end="")  # two spaces per missing column
    for col in range(row):
        print(f"{row} ", end="")
    print()
