n=int(input("enter no of rows"))
for i in range(n+1):
    for j in range(1,n-i+2):
        print("* ",end=" ")
    print()