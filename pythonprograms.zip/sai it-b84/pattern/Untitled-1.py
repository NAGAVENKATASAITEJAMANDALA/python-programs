n=int(input("enter no of rows"))
for row in range(1,n+1):
    for space in range(1,row):
        print("  ",end="")
    for col in range(1,n-row+2):
        print("* ",end="")
    print()

    