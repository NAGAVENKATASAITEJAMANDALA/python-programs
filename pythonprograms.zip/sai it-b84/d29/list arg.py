def values(n):
    return min(n),max(n),sum(n)/len(n)
min,max,avg=values([1,2,3,4,5])
print(f"min={min},max={max},avg={avg}")