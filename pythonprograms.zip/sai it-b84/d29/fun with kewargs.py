def info(**kwargs):
    for key,value in kwargs.items():
        print(f"{key}:{value}")
info(name="sai",height=5.0,city="vijayawada",weight=55)