def hi(name):
    print("good morning",name)
hi("Stuidents")