def hi():
    print("666")
hi()