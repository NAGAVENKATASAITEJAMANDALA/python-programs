def hi():
    return "basket ball"
text=hi()
print(text)