with open("t.txt","w+") as f:
    f.write("hello students!!!!")
    f.seek(0)
    data=f.read()
    print("previous",data)
    new_data=data.replace("students!!!!","future it employees")  
    f.seek(0)
    f.write(new_data)
    f.truncate()
with open("t.txt",'r') as f:
    print("latest",f.read())