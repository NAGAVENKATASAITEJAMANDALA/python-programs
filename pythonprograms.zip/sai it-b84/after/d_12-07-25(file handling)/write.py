file=open("tea.txt","w")
file.write("hi")
file.close()