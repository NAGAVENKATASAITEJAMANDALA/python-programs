import os
os.rename("sample.txt","sai.txt")
print("name chaanged")