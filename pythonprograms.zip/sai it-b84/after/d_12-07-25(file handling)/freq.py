filename=input("enter the filename")
with open(filename) as file:
    text=file.read()
    letter=input("enter a character")
    c=0
    for char in text:
        if char==letter:
            c=c+1
print(letter,"appears",c,"times in the file")

