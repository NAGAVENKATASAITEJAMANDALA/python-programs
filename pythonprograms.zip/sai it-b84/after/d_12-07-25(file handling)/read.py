file=open("sample.txt","r")
data=file.read()
print(data)
file.close()
#single line
file=open("sample.txt","r")
data=file.readline()
print(data)
file.close()