class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None
class DoubleLinkedList:
    def __init__(self):
        self.head = None
    def iae(self, data):  # Insert at end
        newnode = Node(data)
        if self.head is None:
            self.head = newnode
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = newnode
        newnode.prev = temp
    def display_forward(self):  
        temp = self.head
        print("Forward traversal:")
        while temp:
            print(temp.data, end=" <-> ")
            temp = temp.next
        print("None")
    def find_duplicates(self):
        counts = {}
        temp = self.head
        while temp:
            counts[temp.data] = counts.get(temp.data, 0) + 1
            temp = temp.next
        duplicates = {key: val for key, val in counts.items() if val > 1}
        if duplicates:
            print("Duplicate values and their counts:")
            for val, count in duplicates.items():
                print(f"Value {val} appears {count} times")
        else:
            print("No duplicate values found.")
dll = DoubleLinkedList()
n = int(input("Enter the number of elements to insert at end: "))
for i in range(n):
    val = int(input(f"Enter element {i+1}: "))
    dll.iae(val)

dll.display_forward()
dll.find_duplicates()
