def insertion_sort(arr):
тог 1 in range(1, ren(arr)):
key = arr[i] while j >= 0 and arr[j]>key: arr [j + 1] = arr[j] j = i - 1
-=1
arr [j + 1] = key
return arr      
text= input("Enter a string")
ch= list(text)
sort_chars insertion_sort(ch)
print("Sorted characters:", ''.join(ch))