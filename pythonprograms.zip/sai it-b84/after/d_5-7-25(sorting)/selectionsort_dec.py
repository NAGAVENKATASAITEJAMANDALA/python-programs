def selectionsort(arr):
    for i in range(len(arr)):
        min_index=i
        for j in range(i+1,len(arr)):
            if arr[j]>arr[min_index]:
                min_index=j
        arr[i],arr[min_index]=arr[min_index],arr[i]
    return arr
size=int(input('enter numer of elementts'))
arr=[]
print('enter',size,'elements')
for i in range(size):
    num=int(input())
    arr.append(num)
print(arr)
result=selectionsort(arr)
print('sorted array',result)