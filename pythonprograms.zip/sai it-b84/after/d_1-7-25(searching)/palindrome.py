''' program to check wether the given string is  palindrome or not
 and count the char which are repeted'''
s=input("enter")
if s==s[::-1]:
    print("yes it is palindrome")
else:
    print("no it is not palindrome")
freq={}
for ch in s:
    freq[ch]=freq.get(ch,0)+1
print(freq)