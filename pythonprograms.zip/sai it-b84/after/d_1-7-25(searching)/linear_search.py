def linearsearch(arr,key):
    for i in range(len(arr)):
        if arr[i]==key:
            return i
    return-1
size=int(input('enter no of elements'))
arr=[]
for i in range(size):
    num=int(input(f"element{i+1}:"))
    arr.append(num)
    arr.sort()
print(arr)
key=int(input("enter the element to search"))
result=linearsearch(arr,key)
if result != -1:
    print(f"\n element {key} found at {result}")
else:
    print(f"element {key} not found in arr")