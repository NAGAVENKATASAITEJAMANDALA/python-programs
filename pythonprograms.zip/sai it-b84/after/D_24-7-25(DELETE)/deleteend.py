class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def insertatbeg(self, data):
        newnode = Node(data)
        newnode.next = self.head
        self.head = newnode
        print(f"{data} inserted at beginning")

    def insertatend(self, data):
        newnode = Node(data)
        if self.head is None:
            self.head = newnode
            print(f"{data} inserted at end")
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = newnode
        print(f"{data} inserted at end")

    def ipa(self, data, pos):  # Insert at Position
        newnode = Node(data)
        if pos == 1:
            newnode.next = self.head
            self.head = newnode
            print(f"{data} inserted at position 1")
            return
        current = self.head
        count = 1
        while current and count < pos - 1:
            current = current.next
            count += 1
        if not current:
            print("Position out of bounds")
            return
        newnode.next = current.next
        current.next = newnode
        print(f"{data} inserted at position {pos}")

    def display(self):
        current = self.head
        if not current:
            print("Linked list is empty")
            return
        while current:
            print(current.data, end=" --> ")
            current = current.next
        print("None")

    def search(self, key):
        pos = 1
        current = self.head
        while current:
            if current.data == key:
                print(f"{key} found at position {pos} in the linked list")
                return True
            current = current.next
            pos += 1
        print(f"{key} not found in the linked list")
        return False

    def deletebeginning(self):
        if self.head is None:
            print("Linked list is empty. Nothing to delete.")
            return
        deleted_value = self.head.data
        self.head = self.head.next
        print(f"{deleted_value} deleted from the beginning of the linked list")

    def deleteend(self):
        if self.head is None:
            print("Linked list is empty. Nothing to delete.")
            return
        if self.head.next is None:
            deleted_value = self.head.data
            self.head = None
            print(f"{deleted_value} deleted from the end of the linked list")
            return
        current = self.head
        while current.next.next:
            current = current.next
        deleted_value = current.next.data
        current.next = None
        print(f"{deleted_value} deleted from the end of the linked list")


# Usage with menu
l1 = LinkedList()
while True:
    print("\nLinked List Operations")
    print("1. Insert at beginning")
    print("2. Insert at end")
    print("3. Insert at position")
    print("4. Display list")
    print("5. Search for element")
    print("6. Delete at beginning")
    print("7. Exit")
    print("8. Delete at end")  # New option
    
    choice = int(input("Enter your choice: "))
    
    if choice == 1:
        data = int(input("Enter value to insert: "))
        l1.insertatbeg(data)
    elif choice == 2:
        data = int(input("Enter value to insert: "))
        l1.insertatend(data)
    elif choice == 3:
        data = int(input("Enter value to insert: "))
        pos = int(input("Enter position to insert at: "))
        l1.ipa(data, pos)
    elif choice == 4:
        l1.display()
    elif choice == 5:
        val = int(input("Enter the value to search: "))
        l1.search(val)
    elif choice == 6:
        l1.deletebeginning()
    elif choice == 7:
        print("Exiting...")
        break
    elif choice == 8:
        l1.deleteend()
    else:
        print("Invalid choice. Try again.")
