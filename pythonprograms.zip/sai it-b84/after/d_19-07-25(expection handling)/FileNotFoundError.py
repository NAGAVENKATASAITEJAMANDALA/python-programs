try:
    filename = input("Enter the filename: ")
    file=open(filename, 'r')
    number=int(file.readline())
    print("number fromfile",number)
    file.close()
except FileNotFoundError:
    print("Error: The file does not exist.")
except ValueError:
    print("file does not have a integer")
except :
    print("An unexpected error occurred.")
     