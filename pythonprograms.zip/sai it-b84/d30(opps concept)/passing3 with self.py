class cal:
    def values(self,x,y):
        self.x=x
        self.y=y
    def  add(self):
        return self.x+self.y
    def sub(self):
        return  self.x-self.y
    def mul(self):
        return self.x*self.y
c=cal()
c.values(5,6)
print(c.add())
print(c.sub())
print(c.mul())