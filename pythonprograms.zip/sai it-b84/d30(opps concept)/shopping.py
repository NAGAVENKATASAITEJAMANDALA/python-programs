#list or collections through the class
class shopping:
    def __init__(self):
        self.iteams=[]
    def add_iteams(self,iteams):
        self.iteams.append(iteams)
cart=shopping()
cart.add_iteams("5 star")
cart.add_iteams("lizol")
cart.add_iteams("apple") 
print(cart.iteams)