class person:
    def __init__(self, name,height,weight):
        self.name = name
        self.height = height
        self.weight = weight
p=person("sai",5.2,50)
print(p.name,p.height,p.weight)