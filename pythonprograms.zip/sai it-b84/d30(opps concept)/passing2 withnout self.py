class cal:
    def  add(self,x,y):
        return x+y
    def sub(self,x,y):
        return  x-y
c=cal()
print(c.add(5,6))
print(c.sub(15,16))