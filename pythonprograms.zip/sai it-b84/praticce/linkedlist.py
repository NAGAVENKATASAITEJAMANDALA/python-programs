class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
class linkedlist:
    def __init__(self):
        self.head = None
    def insert_at_beg(self, data):
        newnode = Node(data)
        newnode.next = self.head
        self.head = newnode
    def insert_at_end(self, data):
        newnode = Node(data)
        if self.head is None:
            self.head = newnode
            print("Node successfully inserted at end")
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = newnode
        print("Node successfully inserted at end")
    def insert_at_pos(self, data, pos):
        if pos <= 0:
            print("Invalid position")
            return
        if pos == 1:
            self.insert_at_beg(data)
            return
        newnode = Node(data)
        current = self.head
        count = 1
        while current is not None and count < pos - 1:
            current = current.next
            count += 1
        if current is None:
            print("Position out of bounds!")
            return
        newnode.next = current.next
        current.next = newnode
        print(f"Node successfully inserted at position {pos}")
    def display(self):
        current = self.head
        if not current:
            print("Linked list is empty")
            return
        while current:
            print(current.data, end="-->")
            current = current.next
        print("None")
ll = linkedlist()
while True:
    print("\nChoose an option:")
    print("1. Insert at start")
    print("2. Insert at end")
    print("3. Insert at position")
    print("4. Display")
    print("5. Exit")
    choice = input("Enter choice (1-5): ")
    if choice in ['1', '2']:
        n = int(input("How many values do you want to insert? "))
        for i in range(n):
            val = input(f"Enter value{i+1}: ")
            if choice == '1':
                ll.insert_at_beg(val)
            else:
                ll.insert_at_end(val)
        if choice==1:
            print("Node successfully inserted at start")
        else:
            print("Node successfully inserted at end")
    elif choice == '3':
        pos = int(input("Enter position to insert at: "))
        val = input("Enter value to insert: ")
        ll.insert_at_pos(val, pos)
    elif choice == '4':
        ll.display()
    elif choice == '5':
        print("Exiting program.")
        break
    else:
        print("Invalid choice. Please try again.")