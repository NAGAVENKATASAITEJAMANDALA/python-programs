'''class to store the name ad marks of student
use list to store the marks of 3 subjects
1.create  class
2.create a funtion in the class range of 3 subject
3.take manual input
4. displa name along wiht marks in each subject

ex i/p="sai","teja"
       sai=80,52,45
       teja=79,77,69
    o/p
       sai[80,52,69]
       teja=[79,77,69]
       '''
class student:
    def  ins(self,s1,s2,s3):
        self.s1 = s1
        self.s2 = s2
        self.s3 = s3
    def marks (self):
        print([self.s1,self.s2,self.s3]) 
stu1=student()
#stu2=student()
stu1.s1=int(input())
stu1.s2=int(input())
stu1.s3=int(input())
print(stu1.marks)
