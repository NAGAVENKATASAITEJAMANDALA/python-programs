# code for del __del__()
class abc():
    classvar=0
    def __init__(self,var):
        abc.classvar+=2
        self.var=var
        print("the objective value is",var)
        print("the value of class variable is:",abc.classvar)   
    def __del__(self):
        abc.classvar-=1
        print("object with value %d is going out of scope" %self.var)
obj1=abc(10)
obj2=abc(20)
obj3=abc(30)    
del obj1
del obj2
del obj3
