class student:
    def __init__(self,name):
        self.name = name
        self.marks=[]
    def entermarks(self):
        for i in range(3):
            m=int(input(f"enter the marks of {self.name} in subject {i+1}"))
            self.marks.append(m)
    def display(self):
        print(self.name,"got",self.marks)
name1=input("enter name")
s1=student(name1)
s1.entermarks()
name2=input("")
s2=student(name2)
s2.entermarks()
s1.display()
s2.display()

